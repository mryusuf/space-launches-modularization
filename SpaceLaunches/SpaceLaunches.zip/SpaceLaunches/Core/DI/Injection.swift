//
//  Injection.swift
//  SpaceLaunches
//
//  Created by Indra Permana on 15/11/20.
//

import Foundation
import RealmSwift

final class Injection: NSObject {
  
   func provideRepository() -> SpaceRepositoryProtocol {

    let remote: RemoteDataSource = RemoteDataSource.shared
    let realm = try? Realm()
    let local: LocalDataSource = LocalDataSource.shared(realm)
    
    return SpaceRepository.shared(remote, local)
  }
  
  func provideHome() -> HomeUseCase {
    
    return HomeInteractor()
    
  }
  
  func provideLaunches() -> LaunchesUseCase {
    
    let repo = provideRepository()
    return LaunchesInteractor(repo: repo)
    
  }
  
  func provideLaunchDetail(launch: LaunchModel) -> LaunchDetailUseCase {
    
    let repo = provideRepository()
    return LaunchDetailInteractor(repo: repo, launch: launch)
    
  }
  
  func provideLaunchWatchlist() -> LaunchWatchlistUseCase {
    
    let repo = provideRepository()
    return LaunchWatchlistInteractor(repo: repo)
    
  }
  
  func provideAbout() -> AboutUseCase {
    
    let repo = provideRepository()
    return AboutInteractor(repo: repo)
    
  }
  
}
