//
//  AboutModel.swift
//  SpaceLaunches
//
//  Created by Indra Permana on 23/11/20.
//

import Foundation

struct AboutModel {
  
  let name: String
  let email: String
  let imageName: String
  
}
