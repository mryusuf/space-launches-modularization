//
//  HomeRouter.swift
//  SpaceLaunches
//
//  Created by Indra Permana on 15/11/20.
//

import UIKit

protocol HomeRouterProtocol {
  
  var presenter: HomePresenterProtocol? { get set }
  func getViewControllers() -> [UIViewController]
  
}

class HomeRouter {
  
  weak var presenter: HomePresenterProtocol?
  weak var viewController: UIViewController?
  
}

extension HomeRouter: HomeRouterProtocol {
  
  func getViewControllers() -> [UIViewController] {
    
    let launchVC = buildLaunches()
    launchVC.tabBarItem = UITabBarItem(title: "Launches", image: UIImage(named: "launches-true"), tag: 0)
    
    let watchlistVC = buildWatchlist()
    watchlistVC.tabBarItem = UITabBarItem(title: "Watchlist", image: UIImage(named: "watchlist-true"), tag: 1)
    
    let aboutVC = buildAbout()
    aboutVC.tabBarItem = UITabBarItem(tabBarSystemItem: .contacts, tag: 2)
    
    let launchNC = UINavigationController(rootViewController: launchVC)
    let watchlistNC = UINavigationController(rootViewController: watchlistVC)
    let aboutNC = UINavigationController(rootViewController: aboutVC)
    
    return [
      launchNC,
      watchlistNC,
      aboutNC
    ]
  }
  
  func buildLaunches() -> UIViewController {
    let view = LaunchesView()
    var interactor = Injection.init().provideLaunches()
    let presenter = LaunchesPresenter()
    let router = LaunchesRouter()
    
    view.presenter = presenter
    
    presenter.view = view
    presenter.interactor = interactor
    presenter.router = router
    
    interactor.presenter = presenter
    
    router.presenter = presenter
    router.viewController = view
    
    return view
  }
  
  func buildAbout() -> UIViewController {
    let view = AboutView()
    var interactor = Injection.init().provideAbout()
    let presenter = AboutPresenter()
    let router = AboutRouter()
    
    view.presenter = presenter
    
    presenter.view = view
    presenter.interactor = interactor
    presenter.router = router
    
    interactor.presenter = presenter
    
    router.presenter = presenter
    router.viewController = view
    
    return view
  }
  
  func buildWatchlist() -> UIViewController {
    
    let view = LaunchWatchlistView()
    var interactor = Injection.init().provideLaunchWatchlist()
    let presenter = LaunchWatchlistPresenter()
    let router = LaunchWatchlistRouter()
    
    view.presenter = presenter
    
    presenter.view = view
    presenter.interactor = interactor
    presenter.router = router
    
    interactor.presenter = presenter
    
    router.presenter = presenter
    router.viewController = view
    
    return view
    
  }
}
